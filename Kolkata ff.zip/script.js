// Auto FF Result by Time
const results = [
  { time: "10:30 AM", value: 5 },
  { time: "11:30 AM", value: 2 },
  { time: "12:30 PM", value: 8 },
  { time: "01:30 PM", value: 4 },
  { time: "02:30 PM", value: 6 } // add more if needed
];

// Function to update result in table
function updateResult() {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();

  // loop through results array
  results.forEach((item, index) => {
    const [tHour, tMin, tMeridiem] = parseTime(item.time);
    if (hours === tHour && minutes === tMin) {
      // select all td.result
      const tableRows = document.querySelectorAll(".table-box table tr");
      // Skip header row
      if (tableRows[index + 1]) {
        tableRows[index + 1].querySelector(".result").innerText = item.value;
      }
    }
  });
}

// Helper to parse "10:30 AM" to [hours, minutes, AM/PM]
function parseTime(timeStr) {
  const [hm, meridiem] = timeStr.split(" ");
  const [hourStr, minStr] = hm.split(":");
  let hour = parseInt(hourStr);
  const min = parseInt(minStr);
  if (meridiem === "PM" && hour !== 12) hour += 12;
  if (meridiem === "AM" && hour === 12) hour = 0;
  return [hour, min, meridiem];
}

// Update every 1 minute
setInterval(updateResult, 60000);

// Run once on load
updateResult();
// Admin password
const PASSWORD = "kolkataff123"; // change this to your own

document.getElementById("update-btn").addEventListener("click", function() {
  const pass = document.getElementById("admin-password").value;
  const time = document.getElementById("admin-time").value;
  const result = document.getElementById("admin-result").value;
  const msg = document.getElementById("admin-msg");

  if(pass !== PASSWORD) {
    msg.innerText = "Wrong Password!";
    return;
  }

  if(!time || !result) {
    msg.innerText = "Enter Time & Result!";
    return;
  }

  // Find table row
  const tableRows = document.querySelectorAll(".table-box table tr");
  let updated = false;

  tableRows.forEach((row, index) => {
    if(index === 0) return; // skip header
    const timeCell = row.querySelector("td:first-child");
    const resultCell = row.querySelector(".result");
    if(timeCell.innerText === time) {
      resultCell.innerText = result;
      updated = true;
    }
  });

  if(updated) {
    msg.innerText = "Result Updated!";
    // Clear inputs
    document.getElementById("admin-time").value = "";
    document.getElementById("admin-result").value = "";
    document.getElementById("admin-password").value = "";
  } else {
    msg.innerText = "Time not found!";
  }
});